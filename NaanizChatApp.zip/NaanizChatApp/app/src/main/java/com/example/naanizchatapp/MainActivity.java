package com.example.naanizchatapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        check=findViewById(R.id.button_chatbox_send);
//        Intent intent = new Intent(this,MainActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
//        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,intent,0);
       Intent resultIntent =new Intent(this,MainActivity.class);
        TaskStackBuilder stackBuilder=TaskStackBuilder.create(this);
      stackBuilder.addNextIntentWithParentStack(resultIntent);
        PendingIntent resultPendingIntent=stackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);


        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,NotificationChannel.DEFAULT_CHANNEL_ID)
                 .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("ChatApp")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("You have a new message from"))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                 .setContentIntent(resultPendingIntent)
                .setAutoCancel(true);
        NotificationManagerCompat notificationManagerCompat=NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(1,builder.build());



    }
    private void createnotificationchannel(){

    }
}
